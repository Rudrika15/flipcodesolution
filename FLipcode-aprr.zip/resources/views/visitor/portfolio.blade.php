@extends('visitor.layouts.app')
@section('title')
    <title>Flipcode solutions | Portfolio</title>
   
@endsection
@section('content')
    <div class="bg-image parallax">
        <div class="container">
            <div style="display: flex;justify-content: center; font-size:larger;">
                <nav aria-label="breadcrumb">
                    <ol class="breadcrumb">
                        <li class="breadcrumb-item"><a href="/" style="color: #606060;">Home</a></li>
                        <li class="breadcrumb-item active" aria-current="page">Clients</li>
                    </ol>
                </nav>

            </div>
        </div>
    </div>
    <!-- breadcrumb end -->

    <!-- portfolio design  -->
    <div class="container-fluid py-3 bg-light">
        <div class="container py-3">
            <div class="row py-2 bg-light">
                <div class="col-md-12">
                    <!-- Start portfolio Section  -->
                    <div class="mt-5">
                        <a class="anchor" id="portfolio-link"></a>
                        <div id="portfolio" class="container-fluid">
                            <div class="row">
                                <div class="col-lg-12 text-center">
                                    <div class="section-head col-sm-12 ">
                                        <h4><span>Our Clients</span></h4>
                                    </div>
                                    <hr />
                                    <div class="container-fluid">
                                        <div class="row">

                                            <div class="col-md-4  col-sm-12 mt-5">
                                                <div class="card p-3 h-100"
                                                    style="width: 18rem;box-shadow: 0 5px 10px rgba(0,0,0,.2);">
                                                    <img src="{{ asset('client-logo/brand-beans-logo.png') }}"
                                                        class="img-fluid" style="margin-top: 90px;" alt="...">
                                                    <div class="card-body">
                                                        <h5 class="card-title text-center d-none">Name</h5>
                                                        <hr class="w-100">

                                                        <h4 class="card-text text-center" style="color: #2c4964;">
                                                            Brand Beans</p>
                                                    </div>
                                                </div>

                                            </div>
                                            <div class="col-md-4  col-sm-12 mt-5">
                                              <div class="card p-3  h-100"
                                                    style="width: 18rem;box-shadow: 0 5px 10px rgba(0,0,0,.2);">
                                                    <img src="{{ asset('client-logo/cu-shah-logo.jpg') }}"
                                                    class="img-fluid mt-5" style="height: 100px; width:100px; margin-left:70px;" alt="...">

                                                    <div class="card-body">
                                                        <h5 class="card-title text-center d-none">Name</h5>
                                                        <hr class="w-100">

                                                        <h4 class="card-text text-center" style="color: #2c4964;">
                                                          C.U.SHAH Mahila College</p>

                                                    </div>
                                                </div>

                                            </div>
                                            <div class="col-md-4  col-sm-12 mt-5">
                                                <div class="card p-3  h-100"
                                                    style="width: 18rem;box-shadow: 0 5px 10px rgba(0,0,0,.2);">
                                                    <img src="{{ asset('client-logo/alkaviva-logo.png') }}"
                                                    class="img-fluid"  style="margin-top: 90px;" alt="...">

                                                    <div class="card-body">
                                                        <h5 class="card-title text-center d-none">Name</h5>
                                                        <hr class="w-100">

                                                        <h4 class="card-text text-center" style="color: #2c4964;">
                                                         Alka Viva </p>

                                                    </div>
                                                </div>

                                            </div>
                                           
                                          </div>
                                            <div class="row">
                                            <div class="col-md-4  col-sm-12 mt-5">
                                              <div class="card p-3 h-100"
                                                    style="width: 18rem;box-shadow: 0 5px 10px rgba(0,0,0,.2);">
                                                    <img src="{{ asset('client-logo/jd-infra-logo.webp') }}"
                                                    class="img-fluid mt-5"  alt="...">

                                                    <div class="card-body">
                                                        <h5 class="card-title text-center d-none">Name</h5>
                                                        <hr class="w-100">

                                                        <h4 class="card-text text-center" style="color: #2c4964;">
                                                            JD Infra Space</p>

                                                    </div>
                                                </div>

                                            </div>
                                            <div class="col-md-4  col-sm-12 mt-5">
                                              <div class="card p-3  h-100"
                                                  style="width: 18rem;box-shadow: 0 5px 10px rgba(0,0,0,.2);">
                                                  <img src="{{ asset('client-logo/smvs-logo.svg') }}"
                                                  class="img-fluid  p-4" style="margin-top: 100px;"  alt="...">
  
                                                  <div class="card-body">
                                                      <h5 class="card-title text-center d-none">Name</h5>
                                                      <hr class="w-100">
  
                                                      <h4 class="card-text text-center" style="color: #2c4964;">
                                                     Swaminarayan Sanstha</p>
  
                                                  </div>
                                              </div>
                                          </div>
                                            <div class="col-md-4  col-sm-12 mt-5">
                                              <div class="card p-3  h-100"
                                                  style="width: 18rem;box-shadow: 0 5px 10px rgba(0,0,0,.2);">
                                                  <img src="{{ asset('client-logo/ConsultantLogo.png') }}"
                                                  class="img-fluid" style="margin-top: 90px;" alt="...">

                                                  <div class="card-body">
                                                      <h5 class="card-title text-center d-none">Name</h5>
                                                      <hr class="w-100">

                                                      <h4 class="card-text text-center" style="color: #2c4964;">
                                                     Consultant Cube </p>

                                                  </div>
                                              </div>

                                          </div>
              
                                        </div>

                                        <div class="row">
                                          <div class="col-md-4  col-sm-12 mt-5">
                                            <div class="card p-3  h-100"
                                                style="width: 18rem;box-shadow: 0 5px 10px rgba(0,0,0,.2);">
                                                <img src="{{ asset('client-logo/Bitco_Finexpert.png') }}"
                                                class="img-fluid" style="margin-top: 90px;" alt="...">

                                                <div class="card-body">
                                                    <h5 class="card-title text-center d-none">Name</h5>
                                                    <hr class="w-100">

                                                    <h4 class="card-text text-center" style="color: #2c4964;">
                                                   Bitco Fine Expert </p>
                                                </div>
                                            </div>

                                        </div>
                                        <div class="col-md-4  col-sm-12 mt-5">
                                          <div class="card p-3 h-100 "
                                              style="width: 18rem;box-shadow: 0 5px 10px rgba(0,0,0,.2);">
                                              <img src="{{ asset('client-logo/Caves-county-logo.png') }}"
                                              class="img-fluid" style="height: 100px; width:150px; margin-left:50px;margin-top: 90px;" alt="...">

                                              <div class="card-body">
                                                  <h5 class="card-title text-center d-none">Name</h5>
                                                  <hr class="w-100">

                                                  <h4 class="card-text text-center" style="color: #2c4964;">
                                                 Caves County Resort </p>
                                              </div>
                                          </div>
                                      </div>
                                      <div class="col-md-4  col-sm-12 mt-5">
                                        <div class="card p-3  h-100"
                                            style="width: 18rem;box-shadow: 0 5px 10px rgba(0,0,0,.2);">
                                            <img src="{{ asset('client-logo/click-to-care.png') }}"
                                            class="img-fluid" style="margin-top: 90px;" alt="...">

                                            <div class="card-body">
                                                <h5 class="card-title text-center d-none">Name</h5>
                                                <hr class="w-100">

                                                <h4 class="card-text text-center" style="color: #2c4964;">
                                               Click To Care </p>

                                            </div>
                                        </div>
                                    </div>

                                        </div>

                                    {{-- PREVIOUS DESIGN --}}
                                    {{-- <div class="container">
            <div class="row">
              <div class="col-lg-4">
                <div class="thumbnail">
                  <a href="https://codepen.io/hash004/full/obKJvY" target="_blank">
                    <div class="thumbnail-hover text-center">
                      <i class="fa fa-eye fa-4x"></i>
                    </div>
                    <img class="img-responsive" src="https://raw.githubusercontent.com/hash004/freecodecamp/master/portfolioPage/images/projects/tribute-page.png" alt="bruce-lee-tribute-page">
                  </a>
                  <div class="caption">
                    <h3>Tribute Page</h3>
                    <p>Using Bootstrap to build a simple tribute page</p>
                  </div>
                </div>
              </div>
              <div class="col-lg-4">
                <div class="thumbnail">
                  <a href="#" target="_blank">
                    <div class="thumbnail-hover text-center">
                      <i class="fa fa-eye fa-4x"></i>
                    </div>
                    <img class="img-responsive" src="https://images.unsplash.com/photo-1430931071372-38127bd472b8?crop=entropy&dpr=2&fit=crop&fm=jpg&h=275&ixjsv=2.1.0&ixlib=rb-0.3.5&q=50&w=400">
                  </a>
                  <div class="caption">
                    <h3>Placeholder</h3>
                    <p>Placeholder project desciption goes here</p>
                  </div>
                </div>
              </div>
              <div class="col-lg-4">
                <div class="thumbnail">
                  <a href="#" target="_blank">
                    <div class="thumbnail-hover text-center">
                      <i class="fa fa-eye fa-4x"></i>
                    </div>
                    <img src="https://images.unsplash.com/photo-1426260193283-c4daed7c2024?crop=entropy&dpr=2&fit=crop&fm=jpg&h=250&ixjsv=2.1.0&ixlib=rb-0.3.5&q=50&w=400">
                  </a>
                  <div class="caption">
                    <h3>Placeholder</h3>
                    <p>Placeholder project desciption goes here</p>
                  </div>
                </div>
              </div>
            </div>
            <div class="row">
              <div class="col-lg-4">
                <div class="thumbnail">
                  <a href="#" target="_blank">
                    <div class="thumbnail-hover text-center">
                      <i class="fa fa-eye fa-4x"></i>
                    </div>
                    <img src="https://images.unsplash.com/photo-1429728479567-9c51fb49813e?crop=entropy&dpr=2&fit=crop&fm=jpg&h=300&ixjsv=2.1.0&ixlib=rb-0.3.5&q=50&w=400">
                  </a>
                  <div class="caption">
                    <h3>Placeholder</h3>
                    <p>Placeholder project desciption goes here</p>
                  </div>
                </div>
              </div>
              <div class="col-lg-4">
                <div class="thumbnail">
                  <a href="#" target="_blank">
                    <div class="thumbnail-hover text-center">
                      <i class="fa fa-eye fa-4x"></i>
                    </div>
                    <img src="https://images.unsplash.com/photo-1422480723682-a694a43341fb?crop=entropy&dpr=2&fit=crop&fm=jpg&h=275&ixjsv=2.1.0&ixlib=rb-0.3.5&q=50&w=400">
                  </a>
                  <div class="caption">
                    <h3>Placeholder</h3>
                    <p>Placeholder project desciption goes here</p>
                  </div>
                </div>
              </div>
              <div class="col-lg-4">
                <div class="thumbnail">
                  <a href="#" target="_blank">
                    <div class="thumbnail-hover text-center">
                      <i class="fa fa-eye fa-4x"></i>
                    </div>
                    <img src="https://images.unsplash.com/photo-1451968362585-6f6b322071c7?crop=entropy&dpr=2&fit=crop&fm=jpg&h=225&ixjsv=2.1.0&ixlib=rb-0.3.5&q=50&w=400">
                  </a>
                  <div class="caption">
                    <h3>Placeholder</h3>
                    <p>Placeholder project desciption goes here</p>
                  </div>
                </div>
              </div>
            </div>
          </div> --}}
          {{-- end porfolio design --}}
        </div>
                                </div>
                            </div>
                        </div>
                        <!-- End portfolio Section  -->

                    </div>
                </div>
            </div>
        </div>

        <!-- portfolio design  -->



        <!--contact form start  -->
        {{-- <div class="section-head col-sm-12">
  <h4><span>Contact</span> Us</h4>
</div>
<div class="container d-flex justify-content-center mb-5">
  <div class="row py-2 w-75">
      @if (session('success'))
          <div class="alert alert-warning alert-dismissible fade show" role="alert">
              {{ session('success') }}
              <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
          </div>
      @endif
      <div class="col-md-12">
          @include('visitor.commons.contactus')
      </div>
  </div>
</div> --}}

        <!--contact form end  -->
    @endsection
