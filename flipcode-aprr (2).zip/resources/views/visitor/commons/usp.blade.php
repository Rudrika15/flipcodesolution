<div style="width: 100%;margin-top: 30px;" class="usp-bg">
    <div class="container">

        <div class="row">

            <div class="four col-md-3">
                <div class="counter-box colored">
                    <i class="fa fa-thumbs-o-up"></i>
                    <span class="counter">50 </span> <span class="display-6 text-white "><b>+</b></span>
                    <p class="text-white fs-4 fw-bolder">Projects</p>
                </div>
            </div>
            <div class="four col-md-3">
                <div class="counter-box">
                    <i class="fa fa-group"></i>
                    <span class="counter">20 </span> <span class="display-6 text-white "><b>+</b></span>
                    {{-- <p class="text-white fs-4 fw-bolder">Total staff</p> --}}
                    <p class="text-white fs-4 fw-bolder">Teams</p>
                </div>
            </div>
            <div class="four col-md-3">
                <div class="counter-box">
                    <i class="fa  fa-shopping-cart"></i>
                    <span class="counter">50 </span> <span class="display-6 text-white "><b>+</b></span>
                    <p class="text-white fs-4 fw-bolder">Happy Customers</p>
                </div>
            </div>
            <div class="four col-md-3">
                <div class="counter-box">
                    <i class="fa  fa-user"></i>
                    <span class="counter">100 </span> <span class="display-6 text-white "><b>+</b></span>
                    <p class="text-white fs-4 fw-bolder">Interns</p>
                </div>
            </div>
        </div>
    </div>
</div>
